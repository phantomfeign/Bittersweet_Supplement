function bittersweet_functions:structure/mob_spawners/marker/spawns/dungeon/roll
function bittersweet_functions:structure/mob_spawners/marker/spawns/dungeon/roll
function bittersweet_functions:structure/mob_spawners/marker/spawns/dungeon/roll
execute as @e[type=#bittersweet_functions:spawn_checks,tag=!SpawnChecked,tag=!SpawnBypass] run function bittersweet_functions:mob_adjustments/spawn_filter
