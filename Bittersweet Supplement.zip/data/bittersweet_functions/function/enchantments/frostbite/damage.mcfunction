particle minecraft:snowflake ~ ~1 ~ 0.75 0.75 0.75 0 6
execute store result score @s FrostbittenHealth run data get entity @s Health
execute as @s[type=!player] if score @s FrostbittenHealth matches 0..5 run function bittersweet_functions:enchantments/frostbite/ice_statue/become
damage @s 1 minecraft:freeze
playsound minecraft:entity.player.hurt_freeze hostile @a ~ ~ ~ 3 2