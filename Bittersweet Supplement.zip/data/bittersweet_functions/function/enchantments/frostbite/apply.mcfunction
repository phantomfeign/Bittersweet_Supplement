tag @s add bswt.frostbitten
data merge entity @s {TicksFrozen:9999s}
effect give @s minecraft:slowness infinite 0 true
execute unless score @s FrostbiteTimer matches 1.. run scoreboard players set @s FrostbiteTimer 8
scoreboard players add @s FrostbiteTimer 4

#fire
execute unless score @s FireTimer matches 1.. run return fail
scoreboard players set @s FireTimer 0
data modify entity @s HasVisualFire set value 0b
tag @s remove isOnFire