execute unless score @s cooldownMace matches 4 run return fail
scoreboard players set @s cooldownMace 0
playsound minecraft:item.mace.smash_air player @a ~ ~ ~ 4 2
summon minecraft:breeze_wind_charge ~ ~ ~ {Motion:[0.0,-2.0,0.0]}
