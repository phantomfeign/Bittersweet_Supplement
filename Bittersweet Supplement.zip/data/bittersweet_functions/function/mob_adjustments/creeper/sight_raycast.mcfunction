tag @e[type=minecraft:creeper,tag=Watched] remove Watched

#check player sight lines from up to 34 blocks away
execute anchored eyes positioned ^ ^ ^2 if entity @e[type=minecraft:creeper,distance=..1] run tag @e[type=minecraft:creeper,distance=..1] add Watched
execute anchored eyes positioned ^ ^ ^4 if entity @e[type=minecraft:creeper,distance=..1] run tag @e[type=minecraft:creeper,distance=..1] add Watched
execute anchored eyes positioned ^ ^ ^8 if entity @e[type=minecraft:creeper,distance=..2] run tag @e[type=minecraft:creeper,distance=..2] add Watched
execute anchored eyes positioned ^ ^ ^12 if entity @e[type=minecraft:creeper,distance=..2] run tag @e[type=minecraft:creeper,distance=..2] add Watched
execute anchored eyes positioned ^ ^ ^17 if entity @e[type=minecraft:creeper,distance=..3] run tag @e[type=minecraft:creeper,distance=..3] add Watched
execute anchored eyes positioned ^ ^ ^23 if entity @e[type=minecraft:creeper,distance=..3] run tag @e[type=minecraft:creeper,distance=..3] add Watched
execute anchored eyes positioned ^ ^ ^30 if entity @e[type=minecraft:creeper,distance=..4] run tag @e[type=minecraft:creeper,distance=..4] add Watched

#frozen behavior
execute as @e[type=minecraft:creeper,tag=Watched] run effect give @s minecraft:slowness infinite 255 true
execute as @e[type=minecraft:creeper,tag=Watched] run rotate @s facing entity @a[limit=1,sort=nearest] eyes
execute as @e[type=minecraft:creeper,tag=Watched,tag=!StaredAt] at @s run function bittersweet_functions:mob_adjustments/creeper/sting_sound

#unfrozen behavior
execute as @e[type=minecraft:creeper,tag=!Watched] run effect clear @s minecraft:slowness

execute as @e[type=minecraft:creeper,tag=!Watched] positioned ~ ~ ~ if entity @a[distance=..8] run attribute @s minecraft:movement_speed base set 0.25
execute as @e[type=minecraft:creeper,tag=!Watched] positioned ~ ~ ~ if entity @a[distance=9..16] run attribute @s minecraft:movement_speed base set 0.3
execute as @e[type=minecraft:creeper,tag=!Watched] positioned ~ ~ ~ unless entity @a[distance=17..23] run attribute @s minecraft:movement_speed base set 0.4
execute as @e[type=minecraft:creeper,tag=!Watched] positioned ~ ~ ~ unless entity @a[distance=..24] run attribute @s minecraft:movement_speed base set 0.5

