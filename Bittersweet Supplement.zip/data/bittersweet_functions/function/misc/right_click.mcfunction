advancement revoke @s only bittersweet_functions:misc/right_click
execute if items entity @s weapon.mainhand mace run function bittersweet_functions:weapons/mace/wind_charge
execute if items entity @s weapon.mainhand poisonous_potato[custom_data={summon_fangs_straight:true,right_click:true}] run function bittersweet_functions:weapons/fanged_summon/summon_fangs_straight/first
execute if items entity @s weapon.mainhand poisonous_potato[custom_data={summon_fangs_radius:true,right_click:true}] run function bittersweet_functions:weapons/fanged_summon/summon_fangs_radius/first
